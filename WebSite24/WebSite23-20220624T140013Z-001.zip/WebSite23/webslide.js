﻿//var num = 1;
//var item1 = $("#col_AllDiv").html();
//var item2 = $("#item_call").html();
//var item3 = $("#item_tv").html();
//var item4 = $("#item_shop").html();
//$("#link_noAngle").on("click", function () {
//    if (num != 1) {
//        if (num > 1) {
//            num = 1;
//            changeLeftCont(item1);
//        }
//    }
//})
//$("#link_call").on("click", function () {
//    if (num != 2) {
//        if (num > 2) {
//            num = 2;
//            changeLeftCont(item2);
//        } else if (num < 2) {
//            num = 2;
//            changeRightCont(item2);
//        }
//    }
//})
//$("#link_tv").on("click", function () {
//    if (num != 3) {
//        if (num > 3) {
//            num = 3;
//            changeLeftCont(item3);
//        } else if (num < 3) {
//            num = 3;
//            changeRightCont(item3);
//        }
//    }
//})
//$("#link_shop").on("click", function () {
//    if (num != 4) {
//        if (num > 4) {
//            num = 4;
//            changeLeftCont(item4);
//        } else if (num < 4) {
//            num = 4;
//            changeRightCont(item4);
//        }
//    }
//})
//function changeRightCont(item) {
//    $("#col_AllDiv").css("transition", "1s");
//    $("#col_AllDiv").css("transform", "translateX(-100%)");
//    $("#col_AllDiv").css("opacity", "0");
//    setTimeout(function () {
//        $("#col_AllDiv").css("transition", "0s");
//        $("#col_AllDiv").css("transform", "translateX(100%)");
//        $("#col_AllDiv").html(item);
//        setTimeout(function () {
//            $("#col_AllDiv").css("transition", "1s");
//            $("#col_AllDiv").css("transform", "translateX(0%)");
//            $("#col_AllDiv").css("opacity", "1");
//        }, 100)

//    }, 1000);
//}
//function changeLeftCont(item) {
//    $("#col_AllDiv").css("transition", "1s");
//    $("#col_AllDiv").css("transform", "translateX(100%)");
//    $("#col_AllDiv").css("opacity", "0");
//    setTimeout(function () {
//        $("#col_AllDiv").css("transition", "0s");
//        $("#col_AllDiv").css("transform", "translateX(-100%)");
//        $("#col_AllDiv").html(item);
//        setTimeout(function () {
//            $("#col_AllDiv").css("transition", "1s");
//            $("#col_AllDiv").css("transform", "translateX(0%)");
//            $("#col_AllDiv").css("opacity", "1");
//        }, 100)

//    }, 1000);


//}

var item1 = $("#col_AllDiv").html();
var item2 = $("#item_call").html();
var item3 = $("#item_tv").html();
var item4 = $("#item_shop").html();
$("#link_noAngle").on("click", function () {
    fnFade(item1);
})
$("#link_call").on("click", function () {
    fnFade(item2);
})
$("#link_tv").on("click", function () {
    fnFade(item3);
})
$("#link_shop").on("click", function () {
    fnFade(item4);
})

function fnFade(item) {
    if ($("#col_AllDiv").html() != item) {
        $("#col_AllDiv").css("opacity", "0");
        setTimeout(function () {
            $("#col_AllDiv").html(item);
            $("#col_AllDiv").css("opacity", "1");
        }, 500);
    }
   
    //$("#col_AllDiv").fadeToggle("slow", function () {
    //    $("#col_AllDiv").html(item);
    //    $("#col_AllDiv").fadeToggle("slow");
    //});
}